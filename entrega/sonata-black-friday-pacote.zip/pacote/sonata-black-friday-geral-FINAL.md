# Sonata Black Friday 2026: documento geral do vídeo (roteiro, imagens e produção)

Arquivo único para rodar no Claude. Reúne oferta, roteiro, direção visual, personagens, prompts de imagem e animação, produção em Remotion e QA. É a fonte da verdade e substitui os arquivos `sonata-black-friday-claude-brief.md` e `sonata-s3-prompts.md`.

Como usar: este arquivo roda no **Claude Code**, dentro da pasta do projeto no computador do Bernardo. Leia tudo, execute na ordem e pare apenas nos pontos marcados como PARAR (seção 12). Se a sessão não tiver o conector do ElevenLabs, avisar em uma linha e deixar a pasta `assets/audio` pronta para receber os arquivos.

## 0. Estado atual e divisão de ferramentas

Divisão (definida pelo Bernardo):
- **Gemini (Nano Banana e Veo):** todas as imagens e os vídeos sem fala (S3 beat 1, S3 beat 2, S7). O Bernardo gera à mão e salva em `assets/`. O Claude Code não gera essas imagens.
- **ElevenLabs (conectado, com créditos):** o Claude Code gera aqui, com as ferramentas `creative_*`, a voz das falas, a trilha, os efeitos sonoros e o lip sync dos dois clipes da apresentadora (S1 e S6), usando as imagens aprovadas em `assets/img`. Os arquivos vão para `assets/audio` e `assets/video`.
- **Higgsfield:** conectado, mas **sem créditos**. Não usar.
- **Claude Code (este arquivo):** geração de áudio e lip sync no ElevenLabs, montagem em Remotion, textos, preço, legendas, QA e render.
- **Fotos do aparelho:** o Bernardo coloca as fotos reais do par e do carregador em `assets/img`. Listar a pasta, identificar cada foto e pedir PNG com fundo transparente se alguma vier com fundo (a do KV vem com fundo azul).

Estado dos ativos:
- Fichas aprovadas: apresentadora, mãe, avô e neto (criança de 9 anos, polo branca, sala clara).
- S3 beat 1 (imagem A): aprovada. Mãe em primeiro plano à esquerda, olhando para o neto, sorriso educado e atento. Avô ao fundo, neto no centro e apresentadora à direita, de perfil.
- S3 beat 2 (imagem B): aprovada. Cena nova na sala, no sofá: mãe e neto lado a lado, ela ri e toca o ombro dele, luz quente e dourada.
- S1 e S6 (quadro inicial da apresentadora): aprovados. Rosto de frente, meio sorriso, boca fechada, camisa branca e cardigã terracota, mesma sala. Em S1 o topo da cabeça fica perto da zona segura, então o lettering de S1 ocupa a faixa do peito, e não acima da cabeça. Em S6 ela estende o celular, com a tela clara, onde o botão de WhatsApp pode ser colocado na montagem.
- Vídeos de S3 (Gemini, 720x1280, 24 fps, 10 s): gerados. `s3a-mesa-fora.mp4`: usar o trecho de 0 a 5 s (a família ainda está inteira no quadro). `s3b-sala-sofa.mp4`: usar o trecho de 4 a 9 s (close da mãe rindo, com a mão no ombro do neto). Converter para 1080x1920 e 30 fps na montagem e descartar o áudio original.
- Pendentes: S7 (plano B), fotos do aparelho, voz, lip sync de S1 e S6, trilha e efeitos sonoros.

Regras de geração:
- As imagens de S3 usam posições fixas (descritas nos prompts da seção 9). A imagem B é uma cena nova (sala, no sofá, close de dois, luz quente) para contrastar com a A (almoço, plano mais aberto, tom levemente frio). Na montagem, A leva um leve tom frio e B um tom quente.
- Todo prompt de vídeo sem fala termina com: `Soft ambient sound only, no speech, no dialogue, no music.`
- Relações: a apresentadora (45) é filha da mãe (70) e mãe do neto (9). A mãe é avó do neto. O avô (72) é marido da mãe. A mãe e a apresentadora são pessoas diferentes, com traços de família parecidos.

## 1. Resumo

- Peça: Reels e Stories, 9:16, 1080x1920, 30 fps, 39 s (1170 frames).
- Objetivo: conversão. Agendamento de teste auditivo gratuito e conversa no WhatsApp, durante a Black Friday (27/11/2026).
- Uma única oferta: aparelho auditivo RIC **recarregável**, o par + carregador, de R$ 9.600 por R$ 6.490, ou 18x de R$ 400.
- Estrutura: apresentadora abre com o preço, o aparelho aparece em detalhe, duas imagens de família aprofundam o benefício, demonstrações curtas, oferta completa, chamada para o teste gratuito e fechamento com urgência.
- Formatos: vídeo gerado por IA (só a apresentadora), imagens de família com zoom, foto real do aparelho e motion graphics.

## 2. Público e tom

- Quem decide: filha ou filho cuidador, 40 a 50 anos, que pesquisa, compara parcelas e chama no WhatsApp.
- Quem usa: mulher 65+, aposentada ou pensionista, classe média urbana, que quer voltar às atividades sociais e busca conforto, preço e parcela que cabe.
- Tom: próximo, limpo e leve, com afeto. Sem dramatizar a perda auditiva e sem apontar condição de saúde de quem assiste.

## 3. Dados da oferta (fonte da verdade)

| Item | Valor |
|---|---|
| Produto | Aparelho auditivo RIC recarregável, o par + carregador |
| Nome comercial | [A CONFIRMAR] |
| Preço de referência ("de") | R$ 9.600 (informado pela Sonata, que responde pela veracidade) |
| Preço à vista ("por") | R$ 6.490 |
| Desconto | R$ 3.110 (cerca de 32%). O vídeo diz "mais de R$ 3 mil de desconto". Não usar a tarja de 50% do card antigo |
| Parcelamento | 18x de R$ 400 (total parcelado R$ 7.200), com juros de cerca de 1,1% ao mês, a confirmar |
| Inclusos | Carregador e teste auditivo gratuito |
| Validade | Enquanto durarem os estoques |
| Diferenciais | Recarregável, som natural, conexão com celular |
| Proteção contra água | [A CONFIRMAR]. Só aparece no vídeo se confirmada |
| WhatsApp, endereço, logo e paleta | [A CONFIRMAR] |
| Texto legal | [A CONFIRMAR, fornecido pela Sonata] |

Regras:
- Todos os dados vivem em `src/data/offer.ts`. Nenhum número escrito direto nos componentes.
- Todo valor pendente aparece como `[A CONFIRMAR]` na prévia. O script `npm run check:offer` falha o render final se algum sobrar.
- Conferir por código: 9600 - 6490 = 3110 e 18 x 400 = 7200.
- Não mostrar tempo de carregamento nem autonomia da bateria. O foco é "recarregável" e a praticidade.

## 4. Roteiro (39 s)

| Trecho | Tempo | Frames | Tipo | O que aparece | Fala |
|---|---|---|---|---|---|
| S1 | 0 a 5s | 0 a 150 | Vídeo da apresentadora | "Recarregável" em destaque, "De R$ 9.600" riscado, "Por R$ 6.490", "Mais de R$ 3 mil de desconto" | "Aparelho recarregável: o par com carregador, de R$ 9.600 por R$ 6.490." |
| S2 | 5 a 10s | 150 a 300 | Foto real + motion | O par sobe sobre o carregador e o LED verde acende. Zoom no receptor no canal e no fio fino. Callouts: "Receptor no canal", "Fio fino", "Carregador incluso" | "O par já vem com carregador. É só encaixar e recarregar." |
| S3 | 10 a 20s | 300 a 600 | Duas imagens de família + texto | Beat 1 (10 a 15s): mesa de domingo, a mãe com sorriso educado, de fora da conversa. Beat 2 (15 a 20s): na sala, no sofá, a mãe ri com o neto. Entram em texto, um a um: "Responder o neto", "Atender o telefone", "Entender a mesa inteira" | "Sua mãe acena que entendeu, mas vai ficando de fora da conversa. Com o aparelho, ela volta: responde o neto, atende o telefone, entende a mesa." |
| S4 | 20 a 25s | 600 a 750 | Motion (3 demos de 50 frames) | (a) Recarga: o par desce no estojo e o LED verde pulsa, sem números. (b) Som: onda cheia de ruído vira uma linha limpa, rótulo "Som natural". (c) Conexão: ícone de celular liga ao aparelho com ondas | "Recarrega no estojo. Som natural, sem chiado. E conecta no celular." |
| S5 | 25 a 31s | 750 a 930 | Motion da oferta | "De R$ 9.600" riscado, "Por R$ 6.490" gigante, "Mais de R$ 3 mil de desconto", "ou 18x de R$ 400", "Teste auditivo gratuito", rodapé legal | "De R$ 9.600 por R$ 6.490: mais de R$ 3 mil de desconto. Ou 18x de R$ 400." |
| S6 | 31 a 34s | 930 a 1020 | Vídeo da apresentadora | Botão de WhatsApp e selo "Teste gratuito" entram por cima | "Agende gratuitamente seu teste na Sonata." |
| S7 | 34 a 39s | 1020 a 1170 | End card (voz em off) | Foto da loja desfocada, logo, botão pulsando "Clique no link", "Fale com nossa equipe", estoque em letra pequena, endereço, rodapé legal | "A oferta vai até durar o estoque. Clique no link e fale com nossa equipe." |

Notas:
- Fechamento: em S6 a apresentadora faz a chamada ("Agende gratuitamente seu teste na Sonata.") e em S7 a voz em off informa a condição e leva ao clique ("A oferta vai até durar o estoque. Clique no link e fale com nossa equipe."). A frase "Oferta válida enquanto durarem os estoques" fica também escrita em letra pequena, porém legível, em S5 e em S7.

### 4.1 Lettering por trecho (texto na tela)

| Trecho | Lettering principal (grande) | Texto de apoio (menor) |
|---|---|---|
| S1 (0 a 5s) | **RECARREGÁVEL**, depois ~~De R$ 9.600~~ → **Por R$ 6.490**, selo "Mais de R$ 3 mil de desconto" | "O par + carregador", "Black Friday Sonata" |
| S2 (5 a 10s) | **Carregador incluso**, callouts "Receptor no canal" e "Fio fino" | "É só encaixar e recarregar" |
| S3 beat 1 (10 a 15s) | Legenda da fala, com "de fora da conversa" em destaque | Legenda da fala completa |
| S3 beat 2 (15 a 20s) | Um por vez: **Responder o neto**, **Atender o telefone**, **Entender a mesa inteira** | "Com o aparelho, ela volta" |
| S4 (20 a 25s) | **Recarrega no estojo**, **Som natural**, **Conecta no celular** | "Sem chiado" |
| S5 (25 a 31s) | ~~De R$ 9.600~~, **Por R$ 6.490** (gigante), **Mais de R$ 3 mil de desconto**, **ou 18x de R$ 400** | "O par + carregador", "Teste auditivo gratuito", rodapé legal (preço à vista, total parcelado e juros) e, em letra pequena, "Oferta válida enquanto durarem os estoques" |
| S6 (31 a 34s) | **Agende gratuitamente seu teste** + botão de WhatsApp | Selo "Teste gratuito" |
| S7 (34 a 39s) | **Fale com nossa equipe**, botão pulsando "Clique no link" | "Oferta válida enquanto durarem os estoques" (letra pequena, bem legível), logo, endereço e rodapé legal |

Em todo o vídeo: selo fixo "18x de R$ 400 ou R$ 6.490 à vista", legendas da fala e textos dentro das zonas seguras.
- Selo fixo no canto, dentro da zona segura, de S1 a S7: "18x de R$ 400 ou R$ 6.490 à vista, o par com carregador".
- Voz: feminina, pt-BR, calma e próxima, cerca de 45 anos. S3 é voz em off da mesma voz. Com ElevenLabs (créditos disponíveis), escolher o `voice_id` por `creative_list_voices`, dizer qual foi e gerar uma única tomada por fala, sem repetir geração. Criar um flow primeiro e passar o mesmo `flow_id` para a fala e o lip sync de S1 e S6, para os nós poderem se conectar.
- Legendas obrigatórias, em português, com a palavra-chave de cada frase destacada (preço, desconto, "gratuitamente", "estoques").
- Copy segue a skill humanizador-copy: sem travessões, sem "não é X, é Y", frases curtas.

### 4.2 Trilha e efeitos sonoros (ElevenLabs, com créditos)

Gerar no chat com as ferramentas `creative_*` do ElevenLabs (se não houver ferramenta direta para música e efeitos, usar `creative_generate_in_flow`) e salvar em `assets/audio`.

**Trilha**
- Instrumental, fluida e acolhedora, que engaje sem competir com a voz. Violão ou piano leve, percussão suave, baixo discreto, sensação de calor e movimento para frente.
- Tempo moderado (cerca de 95 a 105 bpm), sem vocal, sem picos e sem batida pesada.
- Arco: abertura com energia leve (S1), mais suave e emotiva na mesa (S3, sem dramatizar), volta a crescer em S4 e S5 e chega a um fechamento positivo em S6 e S7.
- 39 a 40 s, com final limpo. Ducking de 12 dB sob a voz e volume final em torno de -14 LUFS.

**Efeitos sonoros** (curtos, suaves e naturais; nada chamativo ou de jogo)
- Transições entre trechos: whoosh macio ou swipe curto, baixo volume.
- Entrada de lettering: pop ou tick leve, um por palavra-chave.
- Preço antigo riscado: traço rápido de caneta ou marcador.
- Preço novo aparece: ding suave e um brilho curto (shimmer).
- LED verde do carregador: tom curto de recarga e brilho suave.
- Demos de S4: ondas sonoras ficando limpas (whoosh que afina) e chime de pareamento Bluetooth ao conectar ao celular.
- Botão de WhatsApp e CTA: clique suave, com pulso discreto no end card.
- Ambientes de S3: som de almoço em família ao fundo (talheres, murmúrio sem palavras) na cena A, e risada baixa e natural na cena B.
- Regra: sem fala nos efeitos, sem música nos efeitos, volume abaixo da voz e da trilha.

## 5. Direção visual do motion

### 5.0 KV suavizado (decisão: integrar às imagens solares)

O KV de Black November da Sonata é azul-marinho e ciano. Para conviver com as cenas quentes de família, o motion usa uma versão suavizada:

| Uso | KV original | Versão suave |
|---|---|---|
| Base dos cartões | Azul-marinho `#002C55` | Creme translúcido `#FCF7EF` (cerca de 92% de opacidade), com borda branca e sombra suave |
| Texto principal e preços | Branco e ciano | Azul-petróleo `#0B3A5B` e tinta `#082842` |
| Destaque, botões e etiqueta de desconto | Ciano `#14F1ED` | Ciano suave `#2BD9CE`, texto escuro por cima |
| Produto | Champagne `#D5A594` | Mantido |
| Apoio pontual | n/a | Terracota `#B46242` (ex.: "Black Friday", risco do preço antigo) |
| Texto secundário | n/a | Cinza-azulado `#687C8C` |

Regras:
- O cartão de oferta fica sobre a imagem da família desfocada e levemente clareada, com véu quente. Nunca fundo azul-marinho sólido em tela cheia.
- As ondas curvas do KV viram um detalhe sutil nos cantos, em ciano ou branco com baixa opacidade.
- Tipografia: Poppins Bold para números e títulos, Poppins Medium e Regular para apoio.
- Logo: versão azul-petróleo sobre creme e branca sobre imagem escura. Se o arquivo não vier, usar texto "SONATA / aparelhos auditivos" como placeholder visível.
- Cena de dor (S3 beat 1): leve correção fria e menos saturada. Cena de volta (S3 beat 2): quente e saturada.
- Referência visual: `sonata-oferta-suave-mockup.png` (trecho da oferta, 25 a 31s).

### 5.1 Parâmetros gerais

- Cores: azul-petróleo e ciano do card atual da Sonata (extrair hex do logo quando chegar), branco e o tom champagne do aparelho. Terracota da apresentadora como apoio pontual.
- Tipografia: a fonte da Sonata, se enviada. Sem ela, Poppins Bold para números e títulos e Nunito para apoio.
- Tamanhos mínimos: preço "por" 200 px, parcela 180 px, texto de apoio 44 px, rodapé legal 28 px.
- Zonas seguras do Reels: topo 270 px, base 385 px, laterais 65 px. Componente `SafeZoneGuide` ligável na prévia.
- Contraste mínimo 4.5:1 em todo texto.
- Movimento: easing suave (spring amortecido ou out-cubic), entradas de 8 a 12 frames, sem piscar acima de 3 Hz, uma mudança visual a cada 3 ou 4 segundos.

## 6. Direção de imagem (mundo e pessoas)

- Mundo: apartamento de bairro, claro e organizado, de classe média. Sofá creme com almofadas verde-sálvia e terracota, planta grande, porta-retratos, janela com luz lateral. Os mesmos elementos aparecem em todas as cenas de casa (o "apartamento da mãe").
- Luz: natural, quente, de janela, com leve contraluz nos cabelos.
- Roupas sempre bem passadas e ajustadas, sem esgarçar. Cabelo arrumado e com brilho. Pele com textura real e aspecto descansado, sem cara de plástico.
- Presença: pessoas vivas, olhos brilhantes, expressão calma e calorosa, movimento natural e contido. Nada de gargalhada de boca aberta nem pose de apresentadora de auditório. Frame inicial de lip sync com boca fechada ou quase.

Personagens:
- **Apresentadora (A):** mulher de 45 anos, cabelo castanho na altura dos ombros com ondas suaves e mechas caramelo, camisa branca e cardigã terracota, brincos e colar finos, celular na mão. Voz de quem dá uma dica, sem depoimento pessoal.
- **Mãe (M):** 70 anos, mesma base de rosto da apresentadora (olhos, sobrancelha, nariz, sorriso), cabelo curto prata, óculos de tartaruga redondos, brincos de pérola, colar fino de prata, blusa azul-acinzentada de manga três quartos com estampa floral discreta e calça azul-marinho.
- **Avô (V):** 72 anos, cabelo branco bem cortado, bigode aparado, camisa azul-clara e calça bege.
- **Neto (N):** 9 anos, cabelo curto escuro, polo branca.

## 7. Blocos de prompt (colar no fim de todo prompt de imagem)

**BLOCO_MARCA**
```
Photorealistic editorial lifestyle photograph, 50mm lens, soft warm daylight from a window with gentle rim light, natural warm colors, palette of cream, golden beige, sage green and dusty blue with terracotta-coral accents, clean uncluttered composition with depth, shallow depth of field, subtle film grain, vertical 9:16 framing. Everyone wears freshly ironed, crisp, well-fitted, tailored clothes with clean seams, perfectly smooth fabric, no wrinkles, no baggy or stretched fabric. Hair is softly styled with natural shine and gentle volume. Skin is healthy, luminous and well-rested with natural texture. People look present and alive, with bright eyes, calm warm expressions and natural, restrained movement. Tidy, welcoming middle-class Brazilian neighborhood setting. Warm, confident, reliable mood between helpful content and advertising.
```

**NEGATIVO** (padrão)
```
Avoid: no stock-photo look, no luxury or designer interior, no wrinkled, stretched, faded or frayed clothes, no tired eyes, no dark circles, no exaggerated laugh, no wide-open mouth, no TV-host or salesperson pose, no big hand gestures, no stiff or blank expression, no flat lighting, no dull colors, no messy or greasy hair, no waxy skin, no sad, lonely or frail elderly people, no oversized hearing aid, no text, no logos, no watermark, no extra fingers, no distorted hands
```

**NEGATIVO_DOR** (só para a imagem S3 beat 1)
```
Avoid: no stock-photo look, no luxury or designer interior, no wrinkled, stretched, faded or frayed clothes, no tired eyes, no dark circles, no crying, no tragic or dramatic sadness, no neglectful or cold family, no frail or ill appearance, no exaggerated laugh, no wide-open mouth, no TV-host or salesperson pose, no big hand gestures, no flat lighting, no dull colors, no messy or greasy hair, no waxy skin, no oversized hearing aid, no text, no logos, no watermark, no extra fingers, no distorted hands
```

Regra de montagem: prompt final = texto da cena + espaço + BLOCO_MARCA + espaço + NEGATIVO (ou NEGATIVO_DOR). Ao pedido "gerar prompts completos", o Claude concatena e salva em `sonata-prompts-completos.md`.

## 8. Fichas de personagem (gerar primeiro, anexar como referência)

Estado: apresentadora, mãe (com blusa floral), avô e neto aprovados.

**Apresentadora (A)**, anexar a imagem aprovada. Para regerar:
```
Brazilian woman, looks her real age of 45, not older, a warm, composed and trustworthy local personality that people in the neighborhood know and turn to for advice. Soft natural waves in shoulder-length chestnut-brown hair with subtle caramel highlights, polished but natural, not TV-styled. Healthy luminous well-rested skin, bright attentive brown eyes with catchlights, defined eyebrows, natural polished makeup with a soft rose-coral lip. Calm confident half-smile with lips closed or barely parted, relaxed face, steady direct eye contact with the camera, like a friend about to give you useful advice. Small gold hoop earrings and a delicate gold necklace. Crisp, perfectly ironed white shirt under a tailored terracotta-coral cardigan, well-fitted, clean lines. Relaxed shoulders, standing slightly angled with a subtle head tilt, one hand holding a smartphone gently at chest height, the other arm resting naturally, no big gestures. Sunlit tidy neighborhood living room: cream sofa with sage-green and terracotta cushions, a lush plant, framed family photos, soft warm daylight from a window with gentle rim light. 50mm portrait lens, f/2, shallow depth of field, natural warm colors, calm, reliable, welcoming mood, vertical 9:16.
```

**Mãe (M)**, anexar a ficha da apresentadora para manter a semelhança de família:
```
Using the attached reference image of the presenter, create her mother: the same family, with the same eye shape and dark brown eyes, same defined eyebrows, same nose, same warm olive skin tone and the same calm half-smile, but a woman of 70 years old, about 25 years older. A senhora, elegant and vital. Short silver-grey bob with soft natural waves, gentle volume and a healthy shine, neatly styled. Healthy luminous skin with natural wrinkles and expression lines, well-rested, bright present eyes with catchlights. Round tortoiseshell glasses, small pearl earrings, a delicate thin silver necklace, a tiny skin-tone behind-the-ear hearing aid almost invisible. Soft dusty-blue crepe blouse with a very subtle small cream floral print, round neckline with gentle pleats, three-quarter sleeves with clean cuffs, perfectly ironed, fluid and well-fitted, navy trousers. No collar, no cardigan, no white shirt. Calm warm half-smile with lips closed or barely parted, steady eye contact with the camera, relaxed shoulders, standing slightly angled, hands gently together at waist height. Half-body portrait in the same sunlit tidy neighborhood living room: cream sofa with sage-green and terracotta cushions, a lush plant, framed family photos, soft warm daylight from a window with gentle rim light. [BLOCO_MARCA] [NEGATIVO]
```

**Avô (V)**:
```
Brazilian man, 72 years old, full white hair neatly cut and combed, trimmed white mustache, light brown skin with natural wrinkles and a healthy glow, crisp ironed light-blue shirt tucked into beige trousers, calm warm smile, bright present eyes, half-body portrait, sunlit living room background with a cream sofa and a lush plant. [BLOCO_MARCA] [NEGATIVO]
```

**Neto (N)**:
```
Brazilian boy, 9 years old, short dark hair neatly cut, crisp ironed white polo shirt, bright cheerful eyes and an easy smile, half-body portrait, sunlit living room background with a cream sofa and a lush plant. [BLOCO_MARCA] [NEGATIVO]
```

## 9. Prompts de cena

Referências a anexar em cada uma estão indicadas. Em todas, a primeira frase mantém as pessoas idênticas às fichas.

### S1: gancho (anexar: apresentadora)

Imagem:
```
Keep the exact same woman as the reference image of the presenter, same face, hair, white shirt and terracotta-coral cardigan. Half-body shot in the same sunlit living room, standing slightly angled toward the camera with a calm confident half-smile, lips closed or barely parted, steady eye contact, one hand holding a smartphone with a blank screen at chest height, the other arm resting naturally. Cream sofa with sage-green and terracotta cushions, a lush plant and framed family photos softly blurred behind her. Eye-level camera, clean space above her head for text. [BLOCO_MARCA] [NEGATIVO]
```
Movimento (com o áudio da fala S1):
```
She starts from a calm half-smile and speaks naturally to the camera with accurate lip sync and restrained, realistic mouth movement, soft blinks, a subtle head nod, a small friendly raise of one finger at the end. Very slow push-in. No exaggerated expressions, no morphing, face and clothes stay identical, no camera shake.
```

### S3 beat 1: a mãe de fora da conversa (anexar: mãe, apresentadora, avô, neto)

Imagem (usar NEGATIVO_DOR):
```
Keep the exact same people as the reference images: the mother (silver bob, round tortoiseshell glasses, dusty-blue floral blouse), the presenter (white shirt and terracotta-coral cardigan) as her daughter, the grandfather (light-blue shirt) and the grandson (white polo). Sunday family lunch at a dining table with a clean white tablecloth, in the dining area of the same apartment as the reference images, with the same window, soft curtains and framed family photos on the wall. Rice, beans, salad and roast chicken served simply on everyday white plates, a jug of juice. Seating, fixed: the mother sits at the left side of the table in the foreground, facing the camera at a three-quarter angle. The grandfather sits at the head of the table to her right, the grandson sits across from her on the right side, and the presenter sits beside the grandson, slightly behind. Camera at table height, from the end of the table, same angle. The family chats animatedly around the table and the grandson is talking, while the mother in the foreground, in sharp focus, wears a polite closed-lip smile and a slightly hesitant, attentive look, her eyes moving from one speaker to another, leaning forward a little to try to follow. She is respectful and dignified, not sad and not crying. The others are warm and loving, simply absorbed in the conversation and a little out of focus behind her. Medium close-up on the mother's face. [BLOCO_MARCA] [NEGATIVO_DOR]
```
Movimento:
```
The grandson talks and gestures lightly, the mother's eyes shift between the speakers, she gives a small polite nod and leans forward slightly, then settles back. Slow push-in on her face. Natural, restrained expressions, no morphing, hair and clothes unchanged.
```

### S3 beat 2: a mãe volta a participar, no sofá (anexar: mãe e neto)

Cena nova e de propósito diferente da A: outro ambiente (sala, no sofá), close de dois, atuação aberta e luz quente e saturada. A cena A fica no almoço, com leve tom frio na montagem. Imagem aprovada.

Imagem:
```
Keep the exact same people as the reference images: the mother (silver bob, round tortoiseshell glasses, dusty-blue floral blouse with three-quarter sleeves) and her grandson (white polo). The cozy living room of the same apartment as the reference images: cream sofa with sage-green and terracotta cushions, a lush plant, framed family photos, a window with soft curtains. The mother and the grandson sit side by side on the sofa, turned toward each other. The boy is telling her something excitedly, gesturing with both hands. The mother, in sharp focus, laughs warmly and openly, leaning in toward him with bright engaged eyes, one hand resting gently on his shoulder, fully present and delighted. Medium close two-shot, camera at eye level, the mother occupying the left of the frame. Warm golden afternoon light from the window, richer and more saturated colors than a neutral scene, glowing rim light on hair. Photorealistic editorial lifestyle photograph, 50mm lens, natural warm colors, palette of cream, golden beige, sage green and dusty blue with terracotta-coral accents, clean uncluttered composition with depth, shallow depth of field, subtle film grain, vertical 9:16 framing. Everyone wears freshly ironed, crisp, well-fitted, tailored clothes with clean seams, perfectly smooth fabric, no wrinkles. Hair is softly styled with natural shine and gentle volume. Skin is healthy, luminous and well-rested with natural texture. Tidy, welcoming middle-class Brazilian neighborhood setting. Warm, joyful, reliable mood between helpful content and advertising. Avoid: no stock-photo look, no luxury or designer interior, no wrinkled, stretched, faded or frayed clothes, no tired eyes, no dark circles, no TV-host or salesperson pose, no stiff or blank expression, no flat lighting, no dull colors, no messy or greasy hair, no waxy skin, no sad, lonely or frail elderly people, no oversized hearing aid, no text, no logos, no watermark, no extra fingers, no distorted hands
```
Movimento (Veo, sem fala):
```
Animate the attached image as a calm, realistic, 8-second vertical shot. Keep the exact same people, faces, clothes, sofa, room, lighting and framing as the image. The boy tells his story with lively hand gestures, the mother listens, then answers him and bursts into a warm, genuine laugh, squeezes his shoulder gently, and he laughs back. Camera: very slow, smooth push-in, no shake, no cuts. Natural, joyful expressions, no morphing, no face changes, hair and clothes unchanged. Warm golden light stays the same. Soft ambient room sound only, no speech, no dialogue, no music.
```

### S6: chamada para o teste gratuito (anexar: apresentadora)

Imagem:
```
Keep the exact same woman as the reference image of the presenter, same face, hair, white shirt and terracotta-coral cardigan, same living room as the opening scene but a closer chest-up angle from a slight three-quarter side view. She holds the smartphone toward the camera with a blank glowing screen, calm warm half-smile with lips closed or barely parted, steady eye contact. Same cream sofa, plant and family photos softly blurred, same soft daylight with gentle rim light. Clean space above her head. [BLOCO_MARCA] [NEGATIVO]
```
Movimento (com o áudio da fala S6):
```
She starts from a calm half-smile and speaks to the camera with accurate lip sync and restrained, realistic mouth movement, a small friendly nod, tilts the phone slightly toward the viewer at the end of the sentence. Very slow push-in. No exaggerated expressions, no morphing, no camera shake.
```

### S7: loja (plano B; o ideal é foto real da loja e da equipe)

Imagem (anexar: mãe, apresentadora):
```
Keep the exact same people as the reference images of the mother (silver bob, round tortoiseshell glasses, dusty-blue floral blouse with three-quarter sleeves) and the presenter (white shirt and terracotta-coral cardigan). Bright, clean hearing-care store reception with a light wooden counter, a green plant and soft daylight through a front window, no visible logos or signs. A friendly attendant, woman around 35 with neat tied-back hair, wearing a crisp ironed navy blouse, smiles warmly while handing a small paper folder to the mother, the presenter standing beside her holding her phone with a calm smile. Warm, welcoming, professional but close. Clean upper third for text. [BLOCO_MARCA] [NEGATIVO]
```
Movimento:
```
Gentle pan to the right, the attendant hands over the folder, the mother smiles and nods, the presenter smiles beside her. No morphing, natural pace.
```

## 10. Produção

### 10.1 Habilidades a ativar antes de qualquer trabalho

Carregar com a ferramenta de skills, nesta ordem. Se alguma não existir na sessão, avisar em uma linha e seguir com a mais próxima.

1. `anthropic-skills:video-making`: obrigatória antes de criar qualquer vídeo.
2. Remotion: `remotion:remotion-best-practices` (roteador), `remotion:remotion-create`, `remotion:remotion-markup` (conteúdo, animação e efeitos), `remotion:remotion-multimedia` (vídeo e áudio com Mediabunny), `remotion:remotion-captions`, `remotion:remotion-studio` e `remotion:remotion-render`.
3. `anthropic-skills:humanizador-copy`: em toda fala, legenda e texto em tela.
4. `anthropic-skills:frontend-design`: direção visual dos overlays e do end card.
5. `design:ux-copy` e `design:accessibility-review` (contraste e legibilidade para 65+).
6. ElevenLabs: voz (`creative_generate_speech`), trilha, efeitos sonoros e lip sync de S1 e S6 a partir das imagens aprovadas, todos acionados pelo Claude Code. Higgsfield está sem créditos e não deve ser usado. Detalhes na seção 10.3, etapa 6.

### 10.2 Ativos esperados

```
assets/
  video/   s1-apresentadora.mp4  s6-apresentadora.mp4  s3a-mesa-fora.mp4  s3b-sala-sofa.mp4  (s7-loja.mp4 só se não houver foto real)
  img/     s1-apresentadora.png  s6-apresentadora.png  s3a-mesa-fora.png  s3b-sala-sofa.png  fotos do aparelho (par e carregador, fundo transparente)  loja.jpg  logo.svg
  audio/   voz-s1.mp3 ... voz-s7.mp3  trilha.mp3  sfx/ (efeitos sonoros do 4.2)
```

- S1 e S6: 4 a 5 s, 9:16, lip sync com o áudio da fala, movimento mínimo, começando com meio sorriso e boca fechada, sem texto na imagem.
- Foto do aparelho: PNG com fundo transparente do par e do carregador, em alta resolução, sem o fundo azul nem os textos do card antigo.
- Trilha: leve, instrumental, livre de direitos, com ducking de 12 dB sob a voz.
- Enquanto um ativo não chegar, usar placeholder visível e seguir em frente.

### 10.3 Passo a passo

1. Carregar as skills da seção 10.1.
2. Criar o projeto Remotion em `sonata-bf` com a skill `remotion-create`.
3. Estruturar: `src/data/offer.ts`, `src/theme.ts`, `src/segments/S1.tsx` a `S7.tsx`, `src/Root.tsx` (composição 1080x1920, 30 fps, 1170 frames).
4. Componentes: `PriceBadge`, `StrikePrice`, `InstallmentHero`, `FeatureCallout`, `BenefitList`, `SoundWave`, `BluetoothLink`, `WhatsAppButton`, `LegalFooter`, `SafeZoneGuide`.
5. Renderizar stills dos frames 0, 75, 200, 380, 520, 650, 700, 800, 900, 1000 e 1150 e conferir cada um.
6. Gerar o áudio e o lip sync no ElevenLabs (créditos disponíveis, uma tomada por geração, sem repetir chamadas):
   - Chamar `creative_create_flow` antes e usar o mesmo `flow_id` em tudo, para os nós poderem se conectar.
   - Voz: `creative_list_voices` com `languages: ["pt"]`, feminina, adulta, calma e próxima (cerca de 45 anos). Escolher uma só, dizer qual foi e usar nas sete falas. Modelo `eleven_v4`, `generations_count: 1`, pt-BR, ritmo tranquilo. Falas na seção 4.
   - Lip sync de S1 e S6: anexar a imagem aprovada (`creative_attach_reference_file` com o arquivo de `assets/img`) e ligar ao áudio da fala. Usar um modelo de imagem + áudio para vídeo falado (por exemplo `bytedance-omnihuman-v1.5` ou `creatify-aurora`; ler `creative_get_model_guide` antes). Resultado: vídeo de 3 a 5 s em 9:16, com movimento mínimo. Se o rosto deformar, avisar e não gastar novas gerações sem checar com o usuário.
   - Trilha e efeitos: conforme a seção 4.2 (`creative_generate_in_flow` com os tipos de nó de música e de efeito sonoro). Conferir o catálogo com `creative_get_flow_node_types` se o modelo não existir.
   - Baixar os arquivos para `assets/audio` e `assets/video` com os nomes da seção 10.2.
   - Higgsfield: sem créditos, não usar.
7. Montar áudio (voz, trilha, efeitos, ducking) e legendas.
8. Trocar placeholders pelos ativos reais conforme chegarem. Em S3, cortar os trechos indicados na seção 0 e aplicar leve tom frio em S3 beat 1 e quente em S3 beat 2.
9. Rodar o QA (seção 11).
10. Exportar: MP4 H.264, 1080x1920, 30 fps, CRF 18 a 20, áudio AAC 192 kbps. Variantes 4:5 e 1:1 por props de layout.
11. Entregar: MP4 final, thumbnail do frame de S5, legendas `.srt` e o projeto compactado.

### 10.4 Repositórios e recursos que qualificam o motion

Oficiais (usar):
- `github.com/remotion-dev/skills`: as skills oficiais de Remotion. Instalar com `npx skills add remotion-dev/skills` se ainda não estiverem na sessão. Cobrem projeto, animação, mídia, legendas, preview e render.
- `github.com/remotion-dev/remotion`: o framework. Consultar a documentação em `remotion.dev/docs`, os templates em `remotion.dev/templates` e os prompts em `remotion.dev/prompts` antes de inventar uma solução.
- Pacotes oficiais úteis neste vídeo: `@remotion/transitions` (cortes suaves entre S1 a S7, com `TransitionSeries`), `@remotion/captions` (legendas por palavra com destaque), `@remotion/shapes` (ondas, pílulas, cartões do KV), `@remotion/lottie` (ícones animados, se houver) e os efeitos sonoros da biblioteca oficial (`remotion.dev/docs/sfx`) para o clique do botão e o brilho do LED.

Comunidade (opcional, só se faltar algo):
- Coleções de skills e templates de Remotion de terceiros (por exemplo, repositórios com transições extras como glitch e light leak). Ler o código antes de usar, não executar scripts de instalação desconhecidos e copiar só o que for necessário. Nunca incluir chaves, tokens ou dados da Sonata em arquivos desses repositórios.

Regras de uso:
- Preferir o oficial e só buscar fora quando o oficial não resolver.
- Registrar no resumo final quais repositórios e pacotes foram usados.
- Se um repositório não puder ser acessado na sessão, seguir com as skills e os pacotes oficiais e avisar em uma linha.

## 11. QA e cuidados de comunicação

- Nenhum `[A CONFIRMAR]` na versão final.
- Contas conferidas por código (9600 - 6490 = 3110 e 18 x 400 = 7200).
- Nenhum número de horas de bateria ou tempo de carregamento na tela ou na fala.
- Nenhum texto fora das zonas seguras. Contraste acima de 4.5:1.
- Legendas sincronizadas com a voz. Volume final em torno de -14 LUFS.
- Duração exata de 39 s. Sem frame preto no fim.
- Copy sem travessões, sem "não é X, é Y" e sem as palavras de IA listadas na skill humanizador-copy.
- Sem "sem juros": o parcelado (R$ 7.200) é maior que o à vista (R$ 6.490). O rodapé legal traz o preço à vista, o total parcelado e a taxa.
- Sem a tarja de 50%. Sem promessa de resistência à água, a menos que confirmada.
- Sem frases que apontem condição de saúde de quem assiste, como "Você ouve mal?". A Meta restringe esse tipo de abordagem. A cena de dor mostra a mãe com respeito e a fala fica em terceira pessoa ("sua mãe").
- "Imbatível" não entra: é superlativo e exige comprovação. Usar o fato "18x de R$ 400".
- As pessoas e as cenas de família são geradas com IA e a Meta pode rotular o conteúdo. Alinhar com a Sonata. O aparelho, o preço, a loja e a equipe aparecem reais.
- Estoque dito em S7 ("A oferta vai até durar o estoque") e escrito em letra pequena em S5 e S7. "Clique no link e fale com nossa equipe" dito em S7.

## 12. Pontos de PARAR

- ElevenLabs tem créditos: gerar sem pedir confirmação a cada chamada, uma tomada por fala. Antes de gerar, conferir que as falas do roteiro estão aprovadas. Higgsfield não tem créditos: não usar.
- Se faltar logo ou paleta oficial, usar a provisória, deixar marcado e avisar.
- Se um dado pendente mudar um número na tela, não adivinhar: manter o placeholder.
- Registrar no resumo final que a veracidade do preço de referência (R$ 9.600) é responsabilidade da Sonata.

## 13. Pendências com a Sonata

- [ ] Nome comercial do modelo.
- [ ] Confirmar que R$ 9.600 foi preço praticado e a taxa de juros do 18x de R$ 400.
- [ ] Proteção contra água (só se for citar).
- [ ] Número do WhatsApp (ou link de agendamento) e endereço da loja.
- [ ] Texto legal da Sonata.
- [ ] Logo (SVG ou PNG), paleta e tipografia.
- [ ] Alinhar o KV com o vídeo: o KV traz "50% de desconto" e "a partir de R$ 6.490", mas o desconto real é de cerca de 32% (R$ 9.600 para R$ 6.490). Também decidir entre "Black November" e "Black Friday".
- [ ] PNG do par e do carregador em fundo transparente, e foto da loja e da equipe.
- [ ] Aceite da Sonata quanto ao uso de pessoas geradas por IA.

## 14. Prompt de partida

Cole isto no Claude Code, dentro da pasta do projeto (com `assets/img`, `assets/video` e `assets/audio` já criadas e as imagens e vídeos salvos):

> Leia `sonata-black-friday-geral.md` e execute do começo ao fim. Ative as skills da seção 10.1 e confira os recursos da seção 10.4. Liste `assets/` e identifique cada arquivo, incluindo as fotos do aparelho. Monte o projeto Remotion com placeholders onde faltar algo. Gere no ElevenLabs a voz das sete falas, o lip sync de S1 e S6, a trilha e os efeitos sonoros conforme a seção 10.3, etapa 6 (uma tomada por geração, sem repetir chamadas, sem usar o Higgsfield). Monte o vídeo, renderize os stills de conferência e rode o QA da seção 11. Me mostre os stills e os áudios antes do render final e liste o que ainda depende da Sonata.
