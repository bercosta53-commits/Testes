# Pacote Sonata Black Friday 2026

## O que tem aqui
- `sonata-preview-com-placeholders.mp4`: vídeo completo de 39 s (1080x1920, -14 LUFS). Imagens e vídeos ainda são placeholders.
- `sonata-bf/`: projeto Remotion. Rode `npm i` e `npm run dev`. Detalhes em `sonata-bf/README.md`.
- `audio/`: voz (voz-s1 a voz-s7), trilha e efeitos (sfx/), já dentro do projeto em `sonata-bf/public/assets/audio`.
- `stills/`: quadros de conferência.
- `sonata-black-friday-geral-FINAL.md`: roteiro e direção.

## Voz
Juliana Moreira (ElevenLabs, voice_id dxIMMSJYSsbUSMhioLNb, eleven_v4). Falas de S1 e S5 foram encurtadas para caber no tempo:
- S1: "Recarregável: o par com carregador por seis mil quatrocentos e noventa."
- S5: "Por seis mil quatrocentos e noventa, ou dezoito vezes de quatrocentos reais."

## O que falta
Do seu lado:
1. Colocar imagens e vídeos do Gemini em `sonata-bf/public/assets/img` e `video` (nomes no README do projeto) e fotos do par e do carregador em PNG transparente.
2. Gerar o lip sync de S1 e S6 com as imagens aprovadas (ElevenLabs).
Da Sonata (em `sonata-bf/src/data/offer.ts`): nome do modelo, WhatsApp, endereço, texto legal, taxa de juros (cerca de 1,1% ao mês), logo, paleta e tipografia. A veracidade do preço de referência (R$ 9.600) é responsabilidade da Sonata.

## Conferir ao ouvir
- Trilha: o ElevenLabs marcou "Instrumental: False". Veja se não há voz cantada.
- Ambientes de S3 têm só 1 s e rodam em loop.
- Legendas com tempo proporcional ao texto, não palavra a palavra.
- Variantes 4:5 e 1:1 ainda não foram feitas.
